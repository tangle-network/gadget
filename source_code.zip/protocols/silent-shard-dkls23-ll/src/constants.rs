pub const SILENT_SHARED_DKLS23_KEYGEN_PROTOCOL_NAME: &str =
    "/tangle/silent-shared-dkls23/keygen/1.0.0";
pub const SILENT_SHARED_DKLS23_SIGNING_PROTOCOL_NAME: &str =
    "/tangle/silent-shared-dkls23/signing/1.0.0";
