pub const GENNARO_DKG_BLS_381_KEYGEN_PROTOCOL_NAME: &str =
    "/tangle/gennaro-dkg-bls-381/keygen/1.0.0";
pub const GENNARO_DKG_BLS_381_SIGNING_PROTOCOL_NAME: &str =
    "/tangle/gennaro-dkg-bls-381/signing/1.0.0";
